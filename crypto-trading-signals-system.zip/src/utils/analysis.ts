/* CRYPE - Technical Analysis Utilities */

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// Calculate EMA (Exponential Moving Average)
export function calculateEMA(prices: number[], period: number): number[] {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  
  // First EMA is SMA
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += prices[i];
  }
  ema.push(sum / period);
  
  // Calculate rest of EMAs
  for (let i = period; i < prices.length; i++) {
    ema.push((prices[i] - ema[i - period]) * multiplier + ema[i - period]);
  }
  
  return ema;
}

// Calculate RSI (Relative Strength Index)
export function calculateRSI(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;
  
  let gains = 0;
  let losses = 0;
  
  for (let i = prices.length - period; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) {
      gains += change;
    } else {
      losses -= change;
    }
  }
  
  const avgGain = gains / period;
  const avgLoss = losses / period;
  
  if (avgLoss === 0) return 100;
  
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  
  return rsi;
}

// Calculate Simple Moving Average
export function calculateSMA(prices: number[], period: number): number {
  if (prices.length < period) return prices[prices.length - 1];
  
  const slice = prices.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

// Find support and resistance levels
export function findSupportResistance(candles: Candle[]): { support: number; resistance: number } {
  const prices = candles.map(c => c.close);
  const recentPrices = prices.slice(-50); // Last 50 candles
  
  // Find local minima and maxima
  const localMins: number[] = [];
  const localMaxs: number[] = [];
  
  for (let i = 2; i < recentPrices.length - 2; i++) {
    if (recentPrices[i] < recentPrices[i-1] && 
        recentPrices[i] < recentPrices[i-2] &&
        recentPrices[i] < recentPrices[i+1] && 
        recentPrices[i] < recentPrices[i+2]) {
      localMins.push(recentPrices[i]);
    }
    if (recentPrices[i] > recentPrices[i-1] && 
        recentPrices[i] > recentPrices[i-2] &&
        recentPrices[i] > recentPrices[i+1] && 
        recentPrices[i] > recentPrices[i+2]) {
      localMaxs.push(recentPrices[i]);
    }
  }
  
  const currentPrice = prices[prices.length - 1];
  
  // Find nearest support (below current price)
  const supports = localMins.filter(p => p < currentPrice);
  const support = supports.length > 0 
    ? Math.max(...supports) 
    : currentPrice * 0.98;
  
  // Find nearest resistance (above current price)
  const resistances = localMaxs.filter(p => p > currentPrice);
  const resistance = resistances.length > 0 
    ? Math.min(...resistances) 
    : currentPrice * 1.02;
  
  return { support, resistance };
}

// Determine market volatility
export function getVolatility(candles: Candle[]): 'low' | 'medium' | 'high' {
  if (candles.length < 20) return 'medium';
  
  const closes = candles.slice(-20).map(c => c.close);
  const avgPrice = closes.reduce((a, b) => a + b, 0) / closes.length;
  
  // Calculate standard deviation as percentage
  const variance = closes.reduce((sum, price) => 
    sum + Math.pow(price - avgPrice, 2), 0) / closes.length;
  const stdDev = Math.sqrt(variance);
  const volatilityPercent = (stdDev / avgPrice) * 100;
  
  if (volatilityPercent < 1) return 'low';
  if (volatilityPercent < 3) return 'medium';
  return 'high';
}

// Get smart timeframes based on volatility
export function getSmartTimeframes(volatility: 'low' | 'medium' | 'high'): {
  trend: string;
  entry: string;
} {
  switch (volatility) {
    case 'low':
      return { trend: '1d', entry: '1h' };
    case 'medium':
      return { trend: '4h', entry: '15m' };
    case 'high':
      return { trend: '1h', entry: '5m' };
  }
}

// Calculate risk/reward
export function calculateRiskReward(entry: number, stopLoss: number, takeProfit: number): number {
  const risk = Math.abs(entry - stopLoss);
  const reward = Math.abs(takeProfit - entry);
  return reward / risk;
}

// Generate signal based on analysis
export function generateSignal(params: {
  ema50: number;
  ema200: number;
  rsi: number;
  currentPrice: number;
  support: number;
  resistance: number;
}): {
  signal: 'BUY' | 'SELL' | 'WAIT';
  reason: string;
  risk: 'low' | 'medium' | 'high';
} {
  const { ema50, ema200, rsi, currentPrice, support, resistance } = params;
  
  // Check if market is sideways (RSI between 45-55)
  const isSideways = rsi >= 45 && rsi <= 55;
  
  // Bullish conditions
  const isUptrend = ema50 > ema200;
  const isOversold = rsi < 35;
  const isAtSupport = currentPrice <= support * 1.02;
  
  // Bearish conditions
  const isDowntrend = ema50 < ema200;
  const isOverbought = rsi > 65;
  const isAtResistance = currentPrice >= resistance * 0.98;
  
  // Generate BUY signal
  if (isUptrend && (isOversold || isAtSupport)) {
    return {
      signal: 'BUY',
      reason: isOversold 
        ? 'Tendencia alcista + RSI sobrevendido' 
        : 'Tendencia alcista + en soporte',
      risk: 'low'
    };
  }
  
  // Generate SELL signal
  if (isDowntrend && (isOverbought || isAtResistance)) {
    return {
      signal: 'SELL',
      reason: isOverbought 
        ? 'Tendencia bajista + RSI sobrecomprado' 
        : 'Tendencia bajista + en resistencia',
      risk: 'low'
    };
  }
  
  // Market is sideways - don't trade
  if (isSideways) {
    return {
      signal: 'WAIT',
      reason: 'Mercado lateral - RSI neutral',
      risk: 'high'
    };
  }
  
  // No clear signal
  return {
    signal: 'WAIT',
    reason: 'Sin confirmación clara',
    risk: 'medium'
  };
}

// Fetch candles from Binance
export async function fetchCandles(symbol: string, interval: string, limit: number = 200): Promise<Candle[]> {
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    return data.map((kline: any[]) => ({
      time: kline[0],
      open: parseFloat(kline[1]),
      high: parseFloat(kline[2]),
      low: parseFloat(kline[3]),
      close: parseFloat(kline[4]),
      volume: parseFloat(kline[5])
    }));
  } catch (error) {
    console.error(`Error fetching candles for ${symbol}:`, error);
    return [];
  }
}

// Fetch current price from Binance
export async function fetchPrice(symbol: string): Promise<number | null> {
  const url = `https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    return parseFloat(data.price);
  } catch (error) {
    console.error(`Error fetching price for ${symbol}:`, error);
    return null;
  }
}
