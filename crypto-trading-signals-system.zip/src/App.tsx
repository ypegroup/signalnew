import { useState, useEffect, useCallback } from 'react';
import {
  fetchCandles,
  fetchPrice,
  calculateEMA,
  calculateRSI,
  findSupportResistance,
  getVolatility,
  getSmartTimeframes,
  generateSignal
} from './utils/analysis';

interface CryptoSignal {
  symbol: string;
  name: string;
  base: string;
  price: number;
  signal: 'BUY' | 'SELL' | 'WAIT';
  reason: string;
  risk: 'low' | 'medium' | 'high';
  trendTimeframe: string;
  entryTimeframe: string;
  entryPrice: number;
  takeProfit: number;
  stopLoss: number;
  riskReward: number;
  trend: 'bullish' | 'bearish' | 'sideways';
  rsi: number;
  ema50: number;
  ema200: number;
}

const CRYPTO_LIST = [
  { symbol: 'BTCUSDT', name: 'Bitcoin', base: 'BTC' },
  { symbol: 'ETHUSDT', name: 'Ethereum', base: 'ETH' },
  { symbol: 'BNBUSDT', name: 'BNB', base: 'BNB' },
  { symbol: 'SOLUSDT', name: 'Solana', base: 'SOL' },
  { symbol: 'XRPUSDT', name: 'XRP', base: 'XRP' },
  { symbol: 'ADAUSDT', name: 'Cardano', base: 'ADA' },
  { symbol: 'DOGEUSDT', name: 'Dogecoin', base: 'DOGE' },
  { symbol: 'AVAXUSDT', name: 'Avalanche', base: 'AVAX' },
  { symbol: 'DOTUSDT', name: 'Polkadot', base: 'DOT' },
  { symbol: 'MATICUSDT', name: 'Polygon', base: 'MATIC' },
  { symbol: 'LINKUSDT', name: 'Chainlink', base: 'LINK' },
  { symbol: 'LTCUSDT', name: 'Litecoin', base: 'LTC' },
];

// Loading skeleton component
const SignalSkeleton = () => (
  <div className="bg-slate-800 rounded-xl p-4 animate-pulse">
    <div className="flex items-center gap-3 mb-4">
      <div className="w-10 h-10 bg-slate-700 rounded-full"></div>
      <div>
        <div className="h-4 w-20 bg-slate-700 rounded mb-2"></div>
        <div className="h-3 w-16 bg-slate-700 rounded"></div>
      </div>
    </div>
    <div className="space-y-2">
      <div className="h-8 w-24 bg-slate-700 rounded"></div>
      <div className="h-3 w-full bg-slate-700 rounded"></div>
    </div>
  </div>
);

// Signal badge component
const SignalBadge = ({ signal, risk }: { signal: string; risk: string }) => {
  const colors: Record<string, string> = {
    BUY: 'bg-green-500/20 text-green-400 border-green-500/30',
    SELL: 'bg-red-500/20 text-red-400 border-red-500/30',
    WAIT: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
  };
  
  const riskColors: Record<string, string> = {
    low: 'text-green-400',
    medium: 'text-yellow-400',
    high: 'text-red-400',
  };
  
  const icons: Record<string, string> = {
    BUY: '🟢',
    SELL: '🔴',
    WAIT: '⚪',
  };
  
  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border ${colors[signal]}`}>
      <span>{icons[signal]}</span>
      <span className="font-bold">{signal}</span>
      <span className={`text-xs ${riskColors[risk]}`}>({risk} riesgo)</span>
    </div>
  );
};

// Signal card component
const SignalCard = ({ data }: { data: CryptoSignal }) => {
  return (
    <div className="bg-slate-800 rounded-xl p-4 hover:bg-slate-750 transition-colors border border-slate-700">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
            {data.name.slice(0, 2)}
          </div>
          <div>
            <h3 className="font-bold text-white">{data.base}/USDT</h3>
            <p className="text-slate-400 text-sm">{data.name}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-white font-mono">${data.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          <p className={`text-xs ${data.trend === 'bullish' ? 'text-green-400' : data.trend === 'bearish' ? 'text-red-400' : 'text-gray-400'}`}>
            📈 {data.trend.toUpperCase()}
          </p>
        </div>
      </div>
      
      <div className="mb-3">
        <SignalBadge signal={data.signal} risk={data.risk} />
      </div>
      
      <div className="text-xs text-slate-400 mb-3">
        <p>📊 TF: {data.trendTimeframe} → {data.entryTimeframe}</p>
        <p>{data.reason}</p>
      </div>
      
      {data.signal !== 'WAIT' && (
        <div className="grid grid-cols-3 gap-2 text-xs bg-slate-900/50 rounded-lg p-2">
          <div className="text-center">
            <p className="text-slate-500">Entrada</p>
            <p className="text-white font-mono">${data.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          <div className="text-center">
            <p className="text-green-400">TP +1%</p>
            <p className="text-green-400 font-mono">${data.takeProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          <div className="text-center">
            <p className="text-red-400">SL -0.5%</p>
            <p className="text-red-400 font-mono">${data.stopLoss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
        </div>
      )}
      
      <div className="mt-2 flex justify-between text-xs text-slate-500">
        <span>RSI: {data.rsi.toFixed(1)}</span>
        <span>EMA: {data.ema50.toFixed(0)}/{data.ema200.toFixed(0)}</span>
        <span className={data.riskReward >= 2 ? 'text-green-400' : 'text-yellow-400'}>
          R/R: 1:{data.riskReward.toFixed(1)}
        </span>
      </div>
    </div>
  );
};

function App() {
  const [signals, setSignals] = useState<CryptoSignal[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzeCrypto = useCallback(async (crypto: { symbol: string; name: string; base: string }): Promise<CryptoSignal | null> => {
    try {
      // Get current price
      const price = await fetchPrice(crypto.symbol);
      if (!price) return null;

      // Get volatility
      const candles1h = await fetchCandles(crypto.symbol, '1h', 100);
      if (candles1h.length === 0) return null;
      
      const volatility = getVolatility(candles1h);
      const { trend: trendTF, entry: entryTF } = getSmartTimeframes(volatility);

      // Fetch data for both timeframes
      const trendCandles = await fetchCandles(crypto.symbol, trendTF, 200);
      const entryCandles = await fetchCandles(crypto.symbol, entryTF, 100);
      
      if (trendCandles.length < 50 || entryCandles.length < 20) return null;

      // Get closes for calculations
      const trendCloses = trendCandles.map(c => c.close);
      const entryCloses = entryCandles.map(c => c.close);

      // Calculate EMAs on trend timeframe
      const ema50 = calculateEMA(trendCloses, 50);
      const ema200 = calculateEMA(trendCloses, 200);
      
      const currentEma50 = ema50[ema50.length - 1];
      const currentEma200 = ema200[ema200.length - 1];

      // Calculate RSI on entry timeframe
      const rsi = calculateRSI(entryCloses);

      // Find support and resistance
      const { support, resistance } = findSupportResistance(entryCandles);

      // Determine trend
      let trend: 'bullish' | 'bearish' | 'sideways' = 'sideways';
      if (currentEma50 > currentEma200) trend = 'bullish';
      else if (currentEma50 < currentEma200) trend = 'bearish';

      // Generate signal
      const signalResult = generateSignal({
        ema50: currentEma50,
        ema200: currentEma200,
        rsi,
        currentPrice: price,
        support,
        resistance
      });

      // Calculate TP and SL
      const takeProfit = signalResult.signal === 'BUY' ? price * 1.01 : price * 0.99;
      const stopLoss = signalResult.signal === 'BUY' ? price * 0.995 : price * 1.005;
      const riskReward = signalResult.signal !== 'WAIT' ? 
        Math.abs((takeProfit - price) / (price - stopLoss)) : 0;

      return {
        symbol: crypto.symbol,
        name: crypto.name,
        base: crypto.base,
        price,
        signal: signalResult.signal,
        reason: signalResult.reason,
        risk: signalResult.risk,
        trendTimeframe: trendTF.toUpperCase(),
        entryTimeframe: entryTF.toUpperCase(),
        entryPrice: price,
        takeProfit,
        stopLoss,
        riskReward,
        trend,
        rsi,
        ema50: currentEma50,
        ema200: currentEma200
      };
    } catch (err) {
      console.error(`Error analyzing ${crypto.symbol}:`, err);
      return null;
    }
  }, []);

  const loadSignals = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const results = await Promise.all(
        CRYPTO_LIST.map(crypto => analyzeCrypto(crypto))
      );
      
      const validSignals = results.filter((s): s is CryptoSignal => s !== null);
      
      // Sort: BUY signals first, then SELL, then WAIT
      const sortOrder = { BUY: 0, SELL: 1, WAIT: 2 };
      validSignals.sort((a, b) => sortOrder[a.signal] - sortOrder[b.signal]);
      
      setSignals(validSignals);
      setLastUpdate(new Date());
    } catch (err) {
      setError('Error al cargar datos. Reintentando...');
    } finally {
      setLoading(false);
    }
  }, [analyzeCrypto]);

  useEffect(() => {
    loadSignals();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadSignals, 30000);
    
    return () => clearInterval(interval);
  }, [loadSignals]);

  // Calculate stats
  const buySignals = signals.filter(s => s.signal === 'BUY').length;
  const sellSignals = signals.filter(s => s.signal === 'SELL').length;
  const waitSignals = signals.filter(s => s.signal === 'WAIT').length;

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-3xl">📊</div>
              <div>
                <h1 className="text-xl font-bold">CRYPE</h1>
                <p className="text-xs text-slate-400">Señales inteligentes para trading seguro</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">
                {lastUpdate ? `Actualizado: ${lastUpdate.toLocaleTimeString()}` : 'Cargando...'}
              </p>
              <p className="text-xs text-green-400">🟢 Datos en tiempo real (Binance)</p>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="bg-slate-800/50 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              <span>Compras: <strong className="text-green-400">{buySignals}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500"></span>
              <span>Ventas: <strong className="text-red-400">{sellSignals}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-gray-500"></span>
              <span>Esperar: <strong className="text-gray-400">{waitSignals}</strong></span>
            </div>
            <div className="ml-auto text-xs text-slate-500">
              💡 "Menos operaciones, mejores decisiones"
            </div>
          </div>
        </div>
      </div>

      {/* Warning Banner */}
      <div className="bg-amber-500/10 border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <p className="text-xs text-amber-400 text-center">
            ⚠️ Este sistema es una herramienta de apoyo. El usuario es responsable de sus decisiones de trading.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {error && (
          <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4 mb-4 text-center">
            <p className="text-red-400">{error}</p>
          </div>
        )}

        {/* Loading State */}
        {loading && signals.length === 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {CRYPTO_LIST.map(crypto => (
              <SignalSkeleton key={crypto.symbol} />
            ))}
          </div>
        )}

        {/* Signals Grid */}
        {!loading && signals.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {signals.map(signal => (
              <SignalCard key={signal.symbol} data={signal} />
            ))}
          </div>
        )}

        {/* Strategy Info */}
        <div className="mt-8 bg-slate-800/50 rounded-xl p-6 border border-slate-700">
          <h2 className="text-lg font-bold mb-4">📋 Estrategia Utilizada</h2>
          <div className="grid md:grid-cols-2 gap-6 text-sm">
            <div>
              <h3 className="font-semibold text-blue-400 mb-2">Análisis Técnico</h3>
              <ul className="space-y-1 text-slate-300">
                <li>• <strong>EMA 50/200</strong> - Determinación de tendencia</li>
                <li>• <strong>RSI</strong> - Sobrevendido (&lt;35) / Sobrecomprado (&gt;65)</li>
                <li>• <strong>Soporte/Resistencia</strong> - Zonas de precio clave</li>
                <li>• <strong>Temporalidad inteligente</strong> - Adaptativa según volatilidad</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-blue-400 mb-2">Gestión de Riesgo</h3>
              <ul className="space-y-1 text-slate-300">
                <li>• <strong>Take Profit:</strong> +1%</li>
                <li>• <strong>Stop Loss:</strong> -0.5%</li>
                <li>• <strong>Ratio Riesgo/Beneficio:</strong> ~1:2</li>
                <li>• <strong>Filtro de seguridad:</strong> Mercado lateral = NO operar</li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 border-t border-slate-700 mt-8">
        <div className="max-w-7xl mx-auto px-4 py-4 text-center text-xs text-slate-500">
          <p>CRYPE - Datos proporcionados por Binance API</p>
          <p className="mt-1">Este sistema NO garantiza ganancias. Úsalo como herramienta de apoyo.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
